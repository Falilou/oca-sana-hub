/**
 * Header Component
 * Main navigation and branding for OCA Sana Hub
 */

'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { toggleTheme, getCurrentTheme } from '@/context/ThemeContext';

interface HeaderProps {
  onEnvironmentChange?: (env: 'PROD' | 'INDUS') => void;
  currentEnvironment?: 'PROD' | 'INDUS';
}

export const Header: React.FC<HeaderProps> = ({ onEnvironmentChange, currentEnvironment = 'PROD' }) => {
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  useEffect(() => {
    // Initialize theme state from DOM
    const currentTheme = getCurrentTheme();
    setTheme(currentTheme);
  }, []);

  const handleThemeToggle = () => {
    toggleTheme();
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
  };

  const handleEnvironmentChange = (env: 'PROD' | 'INDUS') => {
    if (onEnvironmentChange) {
      onEnvironmentChange(env);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur-lg border-b border-slate-800 shadow-lg transition-all duration-300">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group transition-transform duration-300">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-600 to-blue-600 rounded-lg flex items-center justify-center shadow-lg group-hover:shadow-cyan-500/50 transition-shadow">
              <span className="text-white font-bold text-lg">🌐</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">OCA Sana Hub</h1>
              <p className="text-xs text-slate-400">Multi-Country E-Ordering Portal</p>
            </div>
          </Link>

          <div className="flex items-center gap-4">
            {/* Environment Selector - Compact */}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg">
              <span className="text-xs font-semibold text-slate-400">ENV:</span>
              <div className="flex gap-1">
                <button
                  onClick={() => handleEnvironmentChange('PROD')}
                  className={`px-3 py-1 rounded text-xs font-bold transition-all duration-200 ${
                    currentEnvironment === 'PROD'
                      ? 'bg-green-600 text-white shadow-lg shadow-green-600/50'
                      : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                  }`}
                >
                  PROD
                </button>
                <button
                  onClick={() => handleEnvironmentChange('INDUS')}
                  className={`px-3 py-1 rounded text-xs font-bold transition-all duration-200 ${
                    currentEnvironment === 'INDUS'
                      ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/50'
                      : 'bg-slate-700 text-slate-400 hover:bg-slate-600'
                  }`}
                >
                  INDUS
                </button>
              </div>
            </div>

            {/* Theme Toggle - Compact */}
            <button
              onClick={handleThemeToggle}
              className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700 transition-all duration-200"
              aria-label="Toggle theme"
              title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
            >
              <span className="text-lg">{theme === 'dark' ? '☀️' : '🌙'}</span>
            </button>

            {/* Settings Button - Compact */}
            <Link 
              href="/settings"
              className="px-4 py-2 bg-slate-800 border border-slate-700 hover:bg-slate-700 text-white rounded-lg font-semibold transition-all duration-200 flex items-center gap-2 text-sm"
            >
              <span>⚙️</span>
              <span>Settings</span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
