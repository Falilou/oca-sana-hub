'use client';

import { Header } from '@/components/common/Header';
import { PortalGrid } from '@/components/portals/PortalGrid';
import { PortalModal } from '@/components/common/PortalModal';
import { PortalInfo } from '@/types';
import { useState } from 'react';
import { useUserStory } from '@/hooks/useUserStory';

export default function Home() {
  const [selectedPortal, setSelectedPortal] = useState<PortalInfo | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentEnv, setCurrentEnv] = useState<'PROD' | 'INDUS'>('PROD');
  const { logPrompt } = useUserStory({ environment: currentEnv });

  const getFlagImageUrl = (countryCode: string) => {
    const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map((char) => 0x1f1e6 + (char.charCodeAt(0) - 65))
      .map((cp) => cp.toString(16))
      .join('-');

    return `https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/${codePoints}.svg`;
  };

  const handlePortalSelect = (portal: PortalInfo) => {
    setSelectedPortal(portal);
    setIsModalOpen(true);

    // Log the portal selection as a user story
    logPrompt(
      `Access ${portal.name}`,
      `User accessed the ${portal.name} (${portal.countryCode})`,
      `User selected to navigate to ${portal.name} in ${currentEnv} environment`,
      {
        severity: 'medium',
        tags: ['portal-access', 'user-action'],
        metadata: {
          portalCountry: portal.country,
          portalCountryCode: portal.countryCode,
        },
      }
    );
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
  };

  const handleEnvironmentChange = (env: 'PROD' | 'INDUS') => {
    setCurrentEnv(env);
    logPrompt(
      `Environment Switched`,
      `User switched environment to ${env}`,
      `User changed from ${currentEnv} to ${env} environment`,
      {
        severity: 'low',
        tags: ['environment-switch'],
        metadata: {
          previousEnv: currentEnv,
          newEnv: env,
        },
      }
    );
  };

  return (
    <div className="min-h-screen bg-slate-900 transition-colors duration-300">
      <Header 
        onEnvironmentChange={handleEnvironmentChange} 
        currentEnvironment={currentEnv}
      />

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Portals Dashboard</h1>
          <p className="text-slate-400">Select a portal below to access your e-ordering system</p>
        </div>

        {/* All Portals Section */}
        <section className="mb-8">
          <PortalGrid onPortalSelect={handlePortalSelect} environment={currentEnv} />
        </section>
      </main>

      {/* Portal Details Modal */}
      <PortalModal
        portal={selectedPortal}
        isOpen={isModalOpen}
        onClose={handleModalClose}
        environment={currentEnv}
      />

      <footer className="bg-gray-900 dark:bg-black text-white mt-16 py-8 border-t border-gray-800 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-400 dark:text-gray-500">
            © 2026 OCA Sana Hub. All rights reserved. | Powered by Next.js 15 & React
          </p>
        </div>
      </footer>
    </div>
  );
}
