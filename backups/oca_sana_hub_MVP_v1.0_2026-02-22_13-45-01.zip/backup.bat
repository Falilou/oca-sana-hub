@echo off
REM ================================================================
REM OCA Sana Hub - Quick Backup Launcher
REM ================================================================
echo.
echo ========================================
echo   OCA Sana Hub - Quick Backup
echo ========================================
echo.
echo Starting backup process...
echo.

REM Run the PowerShell backup script
powershell.exe -ExecutionPolicy Bypass -File "%~dp0create-backup.ps1"

echo.
echo Press any key to exit...
pause > nul
