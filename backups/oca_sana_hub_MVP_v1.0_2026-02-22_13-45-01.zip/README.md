# 🌐 OCA Sana Hub

## Multi-Country E-Ordering Portal Hub

A modern, comprehensive web application serving as a unified gateway to e-ordering portals across 9 countries with support for PROD (production) and INDUS (testing) environments.

[![Next.js](https://img.shields.io/badge/Next.js-15-black?style=flat-square&logo=next.js)](https://nextjs.org/)
[![React](https://img.shields.io/badge/React-19-blue?style=flat-square&logo=react)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3+-blue?style=flat-square&logo=typescript)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-CSS-06B6D4?style=flat-square&logo=tailwind-css)](https://tailwindcss.com/)

---

## ✨ Features

### 🌍 Multi-Country Support
Access e-ordering portals for: Colombia, Australia, Morocco, Chile, Argentina, Vietnam, South Africa, Malaysia, and South Korea.

### 🔄 Dual Environments
- **PROD**: Production environment for live operations
- **INDUS**: Industrial/Testing environment for quality assurance

### 📊 User Story Logging
- Automatic logging of all user interactions
- Export to JSON and CSV formats
- Browser-based persistence

### 🎨 Modern UI
- Responsive design with Tailwind CSS
- Clean, intuitive interface
- Real-time environment switching

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ (LTS)
- npm 9+

### Installation Steps

1. **Navigate to project**
   ```bash
   cd c:\Users\falseck\oca_sana_hub
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Setup environment variables**
   ```bash
   cp .env.example .env.local
   ```
   Edit `.env.local` with your portal URLs

4. **Start development server**
   ```bash
   npm run dev
   ```

5. **Open in browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

---

## 📖 Documentation

Comprehensive documentation available in `/docs`:

- **[Complete Documentation](docs/README.md)** - Full API reference and overview
- **[Setup Guide](docs/SETUP.md)** - Installation and configuration
- **[User Story Logging](docs/USER_STORIES.md)** - Activity tracking system
- **[Architecture Guide](docs/ARCHITECTURE.md)** - System design and patterns

---

## 🛠️ Available Scripts

```bash
npm run dev      # Start development server
npm run build    # Create production build
npm start        # Run production server
npm run lint     # Run ESLint checks
```

---

## 📂 Project Structure

```
src/
├── components/          # React components
├── services/           # Business logic
├── hooks/              # Custom React hooks
├── config/             # Configuration
├── lib/logging/        # User story logger
├── types/              # TypeScript types
└── portals/            # Country-specific portals
```

---

## 🌍 Supported Countries

- 🇨🇴 Colombia
- 🇦🇺 Australia
- 🇲🇦 Morocco
- 🇨🇱 Chile
- 🇦🇷 Argentina
- 🇻🇳 Vietnam
- 🇿🇦 South Africa
- 🇲🇾 Malaysia
- 🇰🇷 South Korea

---

## 📊 Key Features

- ✅ Multi-country portal hub
- ✅ PROD/INDUS environment switching
- ✅ User story logging and tracking
- ✅ Fully typed with TypeScript
- ✅ Responsive Tailwind CSS design
- ✅ Comprehensive documentation
- ✅ Portal status monitoring
- ✅ Export to JSON/CSV
