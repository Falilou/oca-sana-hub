/**
 * Portal Card Component
 * Displays a card for each country's e-ordering portal
 */

'use client';

import React from 'react';
import { PortalInfo } from '@/types';

interface PortalCardProps {
  portal: PortalInfo;
  onSelect: (portal: PortalInfo) => void;
  isLoading?: boolean;
  environment?: 'PROD' | 'INDUS';
}

export const PortalCard: React.FC<PortalCardProps> = ({ portal, onSelect, isLoading, environment = 'PROD' }) => {
  // Get Twemoji flag image URL for better cross-platform compatibility
  const getFlagImageUrl = (countryCode: string): string => {
    // Convert country code to regional indicator code points
    const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map(char => (127397 + char.charCodeAt(0)).toString(16))
      .join('-');
    return `https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/${codePoints}.svg`;
  };

  const statusColor =
    portal.status === 'active'
      ? 'bg-green-50 dark:bg-green-900 border-green-200 dark:border-green-700'
      : portal.status === 'maintenance'
        ? 'bg-yellow-50 dark:bg-yellow-900 border-yellow-200 dark:border-yellow-700'
        : portal.status === 'inactive'
          ? 'bg-gray-100 dark:bg-gray-800 border-gray-300 dark:border-gray-700'
          : 'bg-red-50 dark:bg-red-900 border-red-200 dark:border-red-700';

  const getStatusBadgeColor = () => {
    switch (portal.status) {
      case 'active':
        return 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100';
      case 'inactive':
        return 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-100';
      case 'maintenance':
        return 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-100';
      case 'offline':
        return 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-100';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-100';
    }
  };

  const getStatusLabel = () => {
    if (portal.status === 'inactive') {
      return 'NO URL CONFIGURED';
    }
    return portal.status.toUpperCase();
  };

  const handleClick = () => {
    // Don't open URL here - let the URL buttons handle it
    // Just call the onSelect callback
    onSelect(portal);
  };

  const handlePublicUrlClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (portal.publicUrl && portal.status === 'active') {
      window.open(portal.publicUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleAdminUrlClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (portal.adminUrl && portal.status === 'active') {
      window.open(portal.adminUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div
      onClick={handleClick}
      className="bg-slate-800/50 border border-slate-700/50 hover:border-cyan-500/50 rounded-lg p-5 transition-all duration-300 cursor-pointer hover:shadow-xl hover:shadow-cyan-500/10"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <img 
            src={getFlagImageUrl(portal.countryCode)} 
            alt={`${portal.name} flag`}
            className="w-12 h-12 object-contain drop-shadow-lg"
          />
          <div>
            <h3 className="text-base font-bold text-white">
              {portal.name.replace(' E-Ordering Portal', '')}
            </h3>
            <div className="text-xs text-slate-400 mt-1">
              {environment}
            </div>
          </div>
        </div>
        <span className={`px-2 py-1 rounded text-xs font-bold border ${getStatusBadgeColor()}`}>
          {getStatusLabel()}
        </span>
      </div>

      {/* Quick Access Buttons - Compact */}
      <div className="flex gap-2">
        <button
          onClick={handlePublicUrlClick}
          disabled={!portal.publicUrl}
          className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all ${
            portal.publicUrl
              ? 'bg-cyan-600/20 text-cyan-400 hover:bg-cyan-600/30 border border-cyan-500/30 hover:border-cyan-500/50 cursor-pointer'
              : 'bg-slate-700/30 text-slate-600 cursor-not-allowed border border-slate-700/50'
          }`}
          title={portal.publicUrl || 'Public URL not configured'}
        >
          <span>🌐</span>
          <span>Portal</span>
        </button>

        <button
          onClick={handleAdminUrlClick}
          disabled={!portal.adminUrl}
          className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all ${
            portal.adminUrl
              ? 'bg-purple-600/20 text-purple-400 hover:bg-purple-600/30 border border-purple-500/30 hover:border-purple-500/50 cursor-pointer'
              : 'bg-slate-700/30 text-slate-600 cursor-not-allowed border border-slate-700/50'
          }`}
          title={portal.adminUrl || 'Admin URL not configured'}
        >
          <span>🔑</span>
          <span>Admin</span>
        </button>
      </div>

      {!portal.publicUrl && !portal.adminUrl && (
        <div className="mt-3 px-2 py-1.5 bg-orange-500/10 border border-orange-500/30 rounded text-xs text-orange-400 text-center">
          ⚠️ Configure URLs in Settings
        </div>
      )}

      {isLoading && (
        <div className="mt-3 flex justify-center">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-cyan-500"></div>
        </div>
      )}
    </div>
  );
};

export default PortalCard;
